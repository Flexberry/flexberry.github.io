// Type: ICSSoft.STORMNET.UI.IEditor
// Assembly: ICSSoft.STORMNET.UI, Version=1.0.0.1, Culture=neutral, PublicKeyToken=21ce651d390c1fa0
// Assembly location: D:\CASEBERRY\CASEBERRY\Case\Bin\Debug\icssoft.stormnet.ui.dll

using ICSSoft.STORMNET;
using Scriptizer.DataObjects;
using System;

namespace ICSSoft.STORMNET.UI
{
    [PublishToEBSD]
    public interface IEditor
    {
        void Edit(DataObject dataobject, string contpath);
        void Edit(DataObject dataobject, string contpath, string propertyname);
        void Edit(DataObject dataobject, string contpath, string propertyname, object tag);
        void FailedSave(Exception e);
        event SaveEventArgsHandler SaveEvent;
        event CancelEventArgsHandler CancelEvent;
        event EditorStoppedEventArgsHandler EditorStoppedEvent;
    }
}
